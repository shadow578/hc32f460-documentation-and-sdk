/**
 *******************************************************************************
 * @file  iap/iap_boot/source/modem.c
 * @brief This file provides firmware functions to manage the Modem.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2022-03-31       CDT             First version
   2023-09-30       CDT             Rename function CRC_CalculateData8 to CRC_CRC16_Calculate
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2022-2023, Xiaohua Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by XHSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 *
 *******************************************************************************
 */

/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "modem.h"

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/
static uint8_t u8FrameData[FRAME_SHELL_SIZE + PACKET_MAX_SIZE];

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/
/**
 * @brief  Modem receive frame.
 * @param  [in] pModemCom               Pointer to a @ref stc_modem_com_t structure
 * @param  [out] u8RxBuff               Pointer to the buffer which the data to be received
 * @param  [out] u16RxLen               Packet size
 * @param  [in]  u32Timeout             Receive timeout(ms)
 * @retval int32_t:
 *           - LL_OK: Receive finished
 *           - LL_ERR: Receive error
 */
static int32_t Modem_RecvFrame(stc_modem_com_t *pModemCom, uint8_t *u8RxBuff, uint16_t *u16RxLen, uint32_t u32Timeout)
{
    uint16_t u16Head, u16Crc16;
    uint16_t u16PacketSize;

    if (LL_OK == pModemCom->RecvData(&u8RxBuff[FRAME_HEAD_INDEX], 2U, u32Timeout)) {
        u16Head = u8RxBuff[FRAME_HEAD_INDEX] + ((uint16_t)u8RxBuff[FRAME_HEAD_INDEX + 1U] << 8U);
        if ((FRAME_HEAD == u16Head) && (LL_OK == pModemCom->RecvData(&u8RxBuff[FRAME_NUM_INDEX], 2U, u32Timeout))) {
            if ((u8RxBuff[FRAME_NUM_INDEX] == (u8RxBuff[FRAME_XORNUM_INDEX] ^ FRAME_NUM_XOR_BYTE)) &&
                (LL_OK == pModemCom->RecvData(&u8RxBuff[FRAME_LENGTH_INDEX], 2U, u32Timeout))) {
                u16PacketSize = u8RxBuff[FRAME_LENGTH_INDEX] + ((uint16_t)u8RxBuff[FRAME_LENGTH_INDEX + 1U] << 8U);
                if (((u16PacketSize >= PACKET_MIN_SIZE) && (u16PacketSize <= PACKET_MAX_SIZE)) &&
                    (LL_OK == pModemCom->RecvData(&u8RxBuff[FRAME_PACKET_INDEX], u16PacketSize + 2U, u32Timeout))) {
                    u16Crc16 = u8RxBuff[FRAME_PACKET_INDEX + u16PacketSize] + ((uint16_t)u8RxBuff[FRAME_PACKET_INDEX + u16PacketSize + 1U] << 8U);
                    if ((uint16_t)CRC_CRC16_Calculate(FRAME_CRC16_INIT_VALUE, CRC_DATA_WIDTH_8BIT, &u8RxBuff[FRAME_PACKET_INDEX], u16PacketSize) == u16Crc16) {
                        *u16RxLen = u16PacketSize;
                        return LL_OK;
                    }
                }
            }
        }
    }

    return LL_ERR;
}

/**
 * @brief  Modem send frame.
 * @param  [in] pModemCom               Pointer to a @ref stc_modem_com_t structure
 * @param  [in] u8TxBuff                Pointer to the buffer which the data to be sent
 * @param  [in] u16TxLen                Buffer length
 * @retval None
 */
static void Modem_SendFrame(stc_modem_com_t *pModemCom, uint8_t *u8TxBuff, uint16_t u16TxLen)
{
    uint32_t u32Crc16;

    u8TxBuff[FRAME_LENGTH_INDEX]     = (uint8_t)(u16TxLen & 0xFFU);
    u8TxBuff[FRAME_LENGTH_INDEX + 1] = (uint8_t)((u16TxLen >> 8U) & 0xFFU);
    u32Crc16 = CRC_CRC16_Calculate(FRAME_CRC16_INIT_VALUE, CRC_DATA_WIDTH_8BIT, &u8TxBuff[FRAME_PACKET_INDEX], u16TxLen);
    u8TxBuff[FRAME_PACKET_INDEX + u16TxLen]      = (uint8_t)(u32Crc16 & 0xFFU);
    u8TxBuff[FRAME_PACKET_INDEX + u16TxLen + 1U] = (uint8_t)((u32Crc16 >> 8U) & 0xFFU);
    pModemCom->SendData(&u8TxBuff[0], (FRAME_PACKET_INDEX + u16TxLen + 2U));
}

/**
 * @brief  Modem process.
 * @param  [in] pModemCom               Pointer to a @ref stc_modem_com_t structure
 * @param  [in] pModemFlash             Pointer to a @ref stc_modem_flash_t structure
 * @param  [in] u32Timeout              Communication timeout
 * @retval int32_t:
 *           - LL_OK: Communication done
 *           - LL_ERR_TIMEOUT: Communication timeout
 */
int32_t Modem_Process(stc_modem_com_t *pModemCom, stc_modem_flash_t *pModemFlash, uint32_t u32Timeout)
{
    uint32_t u32TickCnt = 0U;
    uint16_t u16TxLen;
    uint8_t  u8AddrValid;
    uint16_t u16PacketSize, u16DataSize;
    uint32_t u32FlashAddr = 0U, u32AppAddr = 0U;
    uint32_t u32Crc16, u32Temp;

    for (;;) {
        if (LL_OK == Modem_RecvFrame(pModemCom, &u8FrameData[0], &u16PacketSize, FRAME_RECV_TIMEOUT)) {
            u32TickCnt = 0U;
            u16TxLen = 0U;
            u8AddrValid = 0U;
            /* Checking address validity */
            u16DataSize = u16PacketSize - PACKET_INSTRUCT_SIZE;
            if (PACKET_TYPE_DATA == u8FrameData[PACKET_TYPE_INDEX]) {
                u32FlashAddr = u8FrameData[PACKET_ADDR_INDEX] + ((uint32_t)u8FrameData[PACKET_ADDR_INDEX + 1U] << 8U) +
                               ((uint32_t)u8FrameData[PACKET_ADDR_INDEX + 2U] << 16U) + ((uint32_t)u8FrameData[PACKET_ADDR_INDEX + 3U] << 24U);
                if ((u32FlashAddr >= (pModemFlash->u32FlashBase + IAP_BOOT_SIZE)) &&
                    (u32FlashAddr < (pModemFlash->u32FlashBase + pModemFlash->u32FlashSize))) {
                    u8AddrValid = 1U;
                    u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_OK;
                } else {
                    u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_ADDR_ERR;
                }
            } else {
                u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_OK;
            }
            // Command handle
            switch (u8FrameData[PACKET_CMD_INDEX]) {
                case PACKET_CMD_HANDSHAKE:  /* Reserved */
                    break;
                case PACKET_CMD_JUMP_TO_APP:
                    u32Temp = APP_EXIST_FLAG;
                    pModemFlash->WriteData(APP_EXIST_FLAG_ADDR, (uint8_t *)&u32Temp, 4U);
                    pModemFlash->WriteData(APP_RUN_ADDR, (uint8_t *)&u32AppAddr, 4U);
                    Modem_SendFrame(pModemCom, &u8FrameData[0], PACKET_INSTRUCT_SIZE);
                    return LL_OK;
                case PACKET_CMD_APP_DOWNLOAD:
                    if (1U == u8AddrValid) {
                        if (LL_OK != pModemFlash->WriteData(u32FlashAddr, (uint8_t *)&u8FrameData[PACKET_DATA_INDEX], u16DataSize)) {
                            u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_ERR;
                        }
                    }
                    break;
                case PACKET_CMD_APP_UPLOAD:
                    if (1U == u8AddrValid) {
                        u32Temp = u8FrameData[PACKET_DATA_INDEX] + ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 1U] << 8U) +
                                  ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 2U] << 16U) + ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 3U] << 24U);
                        if (u32Temp > PACKET_DATA_SIZE) {
                            u32Temp = PACKET_DATA_SIZE;
                        }
                        if (LL_OK != pModemFlash->ReadData(u32FlashAddr, &u8FrameData[PACKET_DATA_INDEX], u32Temp)) {
                            u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_ERR;
                        } else {
                            u16TxLen = (uint16_t)u32Temp;
                        }
                    }
                    break;
                case PACKET_CMD_ERASE_FLASH:
                    if (1U == u8AddrValid) {
                        // Check Vector Table Relocation
                        if (LL_OK != pModemFlash->CheckAddrAlign(u32FlashAddr)) {
                            u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_ADDR_ERR;
                        } else {
                            u32Temp = u8FrameData[PACKET_DATA_INDEX] + ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 1U] << 8U) +
                                      ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 2U] << 16U) + ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 3U] << 24U);
                            if ((u32FlashAddr + u32Temp) > (pModemFlash->u32FlashBase + pModemFlash->u32FlashSize)) {
                                u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_ERR;
                            } else {
                                u32AppAddr = u32FlashAddr;
                                /* Erase flash for APP flag sector */
                                pModemFlash->EraseSector(APP_EXIST_FLAG_ADDR, 0U);
                                if (LL_OK != pModemFlash->EraseSector(u32FlashAddr, u32Temp)) {
                                    u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_ERR;
                                }
                            }
                        }
                    }
                    break;
                case PACKET_CMD_FLASH_CRC:
                    if (1U == u8AddrValid) {
                        u32Temp = u8FrameData[PACKET_DATA_INDEX] + ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 1U] << 8U) +
                                  ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 2U] << 16U) + ((uint32_t)u8FrameData[PACKET_DATA_INDEX + 3U] << 24U);
                        u32Crc16 = CRC_CRC16_Calculate(FRAME_CRC16_INIT_VALUE, CRC_DATA_WIDTH_8BIT, (uint8_t *)u32FlashAddr, u32Temp);
                        u8FrameData[PACKET_DATA_INDEX]      = (uint8_t)(u32Crc16 & 0xFFU);
                        u8FrameData[PACKET_DATA_INDEX + 1U] = (uint8_t)((u32Crc16 >> 8U) & 0xFFU);
                        u16TxLen = 2U;
                    }
                    break;
                case PACKET_CMD_APP_UPGRADE:    /* Reserved */
                    break;
                default:
                    u8FrameData[PACKET_RESULT_INDEX] = PACKET_ACK_ERR;
                    break;
            }
            Modem_SendFrame(pModemCom, &u8FrameData[0], PACKET_INSTRUCT_SIZE + u16TxLen);
        } else {
            u32TickCnt += FRAME_RECV_TIMEOUT;
        }
        /* Communication timeout */
        if (u32TickCnt >= u32Timeout) {
            return LL_ERR_TIMEOUT;
        }
    }
}

/******************************************************************************
 * EOF (not truncated)
 *****************************************************************************/
